<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\KategoriM;
use App\Models\ProdukM;
use App\Models\StatusM;
use CodeIgniter\HTTP\ResponseInterface;

class ProdukC extends BaseController
{
    protected $modelProduk;
    protected $modelStatus;
    protected $modelKategori;
    public function __construct()
    {
        $this->modelProduk      = new ProdukM();
        $this->modelStatus      = new StatusM();
        $this->modelKategori    = new KategoriM();
    }

    public function index()
    {
        return view('ProdukV');
    }
    public function formSimpan(){
        $data['status']     = $this->modelStatus->findAll();
        $data['kategori']   = $this->modelKategori->findAll();
        return view('ProdukFormSimpanV',$data);
    }
    public function simpan(){
        $validation = service('validation');
        $request = service('request');
        
  
        $data = [
            'nama_produk' => $this->request->getPost('nama_produk'),
            'harga'       => $this->request->getPost('Harga'),
        ];
        
      
        $validation->setRules([
            'nama_produk' => 'required',
            'harga'       => 'numeric'
        ], [
            'nama_produk' => [
                'required' => 'Nama Produk Harus Di Isi',
            ],
            'harga' => [
                'numeric' => 'Harga Harus Berupa Angka',
            ]
        ]);
        
     
        if (!$validation->run($data)) {
          
            session()->setFlashdata('errorNamaProduk', $validation->getError('nama_produk'));
            session()->setFlashdata('errorHarga', $validation->getError('harga'));
            session()->setFlashdata('id_status', $this->request->getPost('status_id'));
            session()->setFlashdata('id_kategori', $this->request->getPost('kategori_id'));
            
            return redirect()->to('produk/formSimpan')->withInput();
        } else {
          
            $data = [
                'nama_produk' => $this->request->getPost('nama_produk'),
                'harga'       => $this->request->getPost('Harga'),
                'kategori_id' => $this->request->getPost('kategori_id'),
                'status_id'   => $this->request->getPost('status_id'),
            ];
          
            $this->modelProduk->save($data);
        
          
            session()->setFlashdata('pesan', 'Data Produk Dengan Nama = ' . $this->request->getPost('nama_produk') . ' Berhasil Di Simpan');
        
           
            return redirect()->to('produk');
        }
    }
    public function dataAjax(){
        $param['draw']              = isset($_REQUEST['draw'])? $_REQUEST['draw']:'';
        $katakunci                  = isset($_REQUEST['search']['value'])?$_REQUEST['search']['value']:'';
        $start                      = isset($_REQUEST['start'])?$_REQUEST['start']:'';
        $length                     = isset($_REQUEST['length'])?$_REQUEST['length']:'';

        
        $data                           = $this->modelProduk->tampilData($katakunci,$start,$length);
        $jumlahdata                     = $this->modelProduk->tampilData($katakunci);
        $output                         = array(
            'draw'                      => intval($param['draw']),
            'recordsTotal'              => count($jumlahdata),
            'recordsFiltered'           => count($jumlahdata),
            'data'                      => $data
        );
        echo json_encode($output);
    }
    public function hapus($id){
        $this->modelProduk->delete($id);
        session()->setFlashdata('pesan','Data Berhasil Di Hapus');
        return redirect()->to('produk');
    }
    public function formUbah($id){
        
        $data['produk']     = $this->modelProduk->where('id_produk',$id)->findAll($id);
        $data['kategori']   = $this->modelKategori->findAll();
        $data['status']     = $this->modelStatus->findAll();
        return view('ProdukFormUbahV',$data);
    }
    public function ubah(){
        $validation = service('validation');
        $request = service('request');
        
  
        $data = [
            'nama_produk' => $this->request->getPost('nama_produk'),
            'harga'       => $this->request->getPost('Harga'),
        ];
        
      
        $validation->setRules([
            'nama_produk' => 'required',
            'harga'       => 'numeric'
        ], [
            'nama_produk' => [
                'required' => 'Nama Produk Harus Di Isi',
            ],
            'harga' => [
                'numeric' => 'Harga Harus Berupa Angka',
            ]
        ]);
        
     
        if (!$validation->run($data)) {
          
            session()->setFlashdata('errorNamaProduk', $validation->getError('nama_produk'));
            session()->setFlashdata('errorHarga', $validation->getError('harga'));
            session()->setFlashdata('id_status', $this->request->getPost('status_id'));
            session()->setFlashdata('id_kategori', $this->request->getPost('kategori_id'));
            
            return redirect()->to('produk/formUbah/'.$this->request->getPost('id_produk'))->withInput();
        } else {
          
          
            $this->modelProduk->set('nama_produk',$this->request->getPost('nama_produk'));
            $this->modelProduk->set('harga',$this->request->getPost('Harga'));
            $this->modelProduk->set('kategori_id',$this->request->getPost('kategori_id'));
            $this->modelProduk->set('status_id',$this->request->getPost('status_id'));
            $this->modelProduk->where('id_produk',$this->request->getPost('id_produk'));

            $this->modelProduk->update();
        
          
            session()->setFlashdata('pesan', 'Data Produk Dengan Nama = ' . $this->request->getPost('nama_produk') . ' Berhasil Di Ubah');
        
           
            return redirect()->to('produk');
        }
    }
}
