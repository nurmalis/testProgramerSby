<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\KategoriM;
use CodeIgniter\HTTP\ResponseInterface;

class KategoriC extends BaseController
{
    public $modelKategori;
    public function __construct()
    {
        $this->modelKategori   = new KategoriM();
    }
    public function index()
    {
        return view('KategoriV');
    }
    
    public function formSimpan(){
        return view('KategoriFormSimpanV');
    }
    public function simpan(){
        $validation     = service('validation');
        $request        = service('request');

        $data               = [
            'nama_kategori'   => $this->request->getPost('nama_kategori'),
        ];
        $validation->setRules([
            'nama_kategori'   =>'required'
        ],[
            'nama_kategori'   =>[
                'required'  =>'Nama Kategori Harus Di Isi'
            ]
        ]);
        if(!$validation->run($data)){
            session()->setFlashdata('errorNamaKategori',$validation->getError('nama_kategori'));
            return redirect()->to('kategori/formSimpan')->withInput();
        }else{
           $this->modelKategori->save($data);
           session()->setFlashdata('pesan','Data Kategori Dengan Nama = '.$this->request->getPost('nama_kategori').' Berhasil Di Simpan');
           return redirect()->to('kategori');
        }
    }
    public function dataAjax(){
        $param['draw']              = isset($_REQUEST['draw'])? $_REQUEST['draw']:'';
        $katakunci                  = isset($_REQUEST['search']['value'])?$_REQUEST['search']['value']:'';
        $start                      = isset($_REQUEST['start'])?$_REQUEST['start']:'';
        $length                     = isset($_REQUEST['length'])?$_REQUEST['length']:'';

        
        $data                           = $this->modelKategori->tampilData($katakunci,$start,$length);
        $jumlahdata                     = $this->modelKategori->tampilData($katakunci);
        $output                         = array(
            'draw'                      => intval($param['draw']),
            'recordsTotal'              => count($jumlahdata),
            'recordsFiltered'           => count($jumlahdata),
            'data'                      => $data
        );
        echo json_encode($output);
    }
    public function hapus($id){
        $this->modelKategori->delete($id);
        session()->setFlashdata('pesan','Data Berhasil Di Hapus');
        return redirect()->to('kategori');
    }
    public function formUbah($id){
        $data['kategori']     = $this->modelKategori->where('id_kategori',$id)->findAll($id);
        return view('KategoriFormUbahV',$data);
    }
    public function ubah(){
        $validation     = service('validation');
        $request        = service('request');

        $data               = [
            'nama_kategori'   => $this->request->getPost('nama_kategori'),
        ];
        $validation->setRules([
            'nama_kategori'   =>'required'
        ],[
            'nama_kategori'   =>[
                'required'  =>'Nama Kategori Harus Di Isi'
            ]
        ]);

        if(!$validation->run($data)){
            session()->setFlashdata('errorNamaKategori',$validation->getError('nama_kategori'));
            return redirect()->to('kategori/formUbah/' . $this->request->getPost('id_kategori'))->withInput();
        }else{
           $this->modelKategori->set('nama_kategori',$this->request->getPost('nama_kategori'));
           $this->modelKategori->where('id_kategori',$this->request->getPost('id_kategori'));
           $this->modelKategori->update();
           session()->setFlashdata('pesan','Data Berhasil Di ubah');
           return redirect()->to('kategori');
        }
    }
}
