<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\StatusM;
use CodeIgniter\HTTP\ResponseInterface;

class StatusC extends BaseController
{
    public $modelStatus;
    public function __construct()
    {
        $this->modelStatus   = new StatusM();
    }
    public function index()
    {
        return view('statusV');        
    }
    public function formSimpan(){
        return view('StatusFormSimpanV');
    }
    public function simpan(){
        $validation     = service('validation');
        $request        = service('request');

        $data               = [
            'nama_status'   => $this->request->getPost('nama_status'),
        ];
        $validation->setRules([
            'nama_status'   =>'required'
        ],[
            'nama_status'   =>[
                'required'  =>'Nama Status Harus Di Isi'
            ]
        ]);

        if(!$validation->run($data)){
            session()->setFlashdata('errorNamaStatus',$validation->getError('nama_status'));
            return redirect()->to('status/formSimpan')->withInput();
        }else{
           $this->modelStatus->save($data);
           session()->setFlashdata('pesan','Data Status Dengan Nama = '.$this->request->getPost('nama_status').' Berhasil Di Simpan');
           return redirect()->to('status');
        }
    }
    public function dataAjax(){
        $param['draw']              = isset($_REQUEST['draw'])? $_REQUEST['draw']:'';
        $katakunci                  = isset($_REQUEST['search']['value'])?$_REQUEST['search']['value']:'';
        $start                      = isset($_REQUEST['start'])?$_REQUEST['start']:'';
        $length                     = isset($_REQUEST['length'])?$_REQUEST['length']:'';

        
        $data                           = $this->modelStatus->tampilData($katakunci,$start,$length);
        $jumlahdata                     = $this->modelStatus->tampilData($katakunci);
        $output                         = array(
            'draw'                      => intval($param['draw']),
            'recordsTotal'              => count($jumlahdata),
            'recordsFiltered'           => count($jumlahdata),
            'data'                      => $data
        );
        echo json_encode($output);
    }
    public function hapus($id){
        $this->modelStatus->delete($id);
        session()->setFlashdata('pesan','Data Berhasil Di Hapus');
        return redirect()->to('status');
    }
    public function formUbah($id){
        $data['status']     = $this->modelStatus->where('id_status',$id)->findAll($id);
        return view('StatusFormUbahV',$data);
    }
    public function ubah(){
        $validation     = service('validation');
        $request        = service('request');

        $data               = [
            'nama_status'   => $this->request->getPost('nama_status'),
        ];
        $validation->setRules([
            'nama_status'   =>'required'
        ],[
            'nama_status'   =>[
                'required'  =>'Nama Status Harus Di Isi'
            ]
        ]);

        if(!$validation->run($data)){
            session()->setFlashdata('errorNamaStatus',$validation->getError('nama_status'));
            return redirect()->to('status/formUbah/' . $this->request->getPost('id_status'))->withInput();
        }else{
           $this->modelStatus->set('nama_status',$this->request->getPost('nama_status'));
           $this->modelStatus->where('id_status',$this->request->getPost('id_status'));
           $this->modelStatus->update();
           session()->setFlashdata('pesan','Data Berhasil Di ubah');
           return redirect()->to('status');
        }
    }
}
