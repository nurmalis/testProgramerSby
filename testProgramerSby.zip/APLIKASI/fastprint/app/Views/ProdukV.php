<?= $this->extend('AdminTemplate/AdminTemplate') ?>
<?= $this->section('content') ?>

<!-- Content Row -->
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Produk</h1>
</div>
<?php 

   if (session()->getFlashdata('pesan')) {
       // Menampilkan pesan dalam format div dengan class 'alert' atau semacamnya
       echo '<div class="alert alert-info">' .session()->getFlashdata('pesan') . '</div>';
   }
?>

<div class="row">
    <!-- Content Column -->
    <div class="col-lg-12 mb-4">

        <!-- Illustrations -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA PRODUK</h6>
            </div>
            <div class="card-body">
                    <a class="btn btn-success btn-sm" href="<?= base_url('produk/formSimpan') ?>" role="button">Tambah</a>
                    <div class="table-responsive">
                                <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Produk</th>
                                            <th>Harga</th>
                                            <th>Kategori</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>

            </div>
        </div>
    </div>
</div>
    


    <!-- Page level custom scripts -->
    <script src="<?= base_url() ?>datatable/jquery-3.7.1.js"></script>
    <script src="<?= base_url() ?>datatable/dataTables.js"></script>
    

    <script>
        let x="ok";
       new DataTable('#example', {
            ajax: {
                url: '<?= base_url('produk/dataAjax') ?>',
                type: 'POST'
            },
            columns: [
                {  data: null,
                    render: function(data,type,row,meta){
                        return meta.row+meta.settings._iDisplayStart+1;
                    }
                 },
                { data: 'nama_produk' },
                { data: 'harga' },
                { data: 'nama_kategori' },
                { data: 'nama_status' },
                { 
                    data: null, 
                    render: function(data, type, row, meta) {
                        var id      = row.id_produk; 
                        var nama    = row.nama_produk; 
                        return `
                            <a class="btn btn-primary btn-sm" href="/produk/formUbah/${id}" role="button">UBAH</a>
                            <a  class="btn btn-danger btn-sm" href="/produk/hapus/${id}" onclick="return confirm('Apakah Anda yakin ingin menghapus data produk = ${nama}?')">DELETE</a>
                        `;
                    }
                 }
            ],
            processing: true,
            serverSide: true
        });
    </script>
<?= $this->endSection() ?>