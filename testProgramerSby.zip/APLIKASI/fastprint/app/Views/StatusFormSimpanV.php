<?= $this->extend('AdminTemplate/AdminTemplate') ?>
<?= $this->section('content') ?>

<!-- Content Row -->
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Status</h1>
</div>
<a class="btn btn-success btn-sm" href="<?=base_url('status')?>" role="button"><< KEMBALI</a>
<div class="row">
    <!-- Content Column -->
    <div class="col-lg-12 mb-4">

        <!-- Illustrations -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">FORM INSERT STATUS</h6>
            </div>
            <div class="card-body">
                    <form method="post" action="<?= base_url('status/simpan') ?>">
                        <div class="form-group">
                            <label for="formGroupExampleInput">Nama Status </label>
                            <input type="text" 
                                class="form-control <?= session()->getFlashdata('errorNamaStatus')?'is-invalid':''?>" 
                                id="formGroupExampleInput" 
                                placeholder="Nama Status" 
                                name="nama_status" 
                                value="<?= old('status') ?>">
                            <div class="invalid-feedback">
                                <?= session()->getFlashdata('errorNamaStatus')?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="SIMPAN" class="form-control btn btn-primary btn-sm btn-block" id="formGroupExampleInput2" placeholder="Another input">
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>
   


  
<?= $this->endSection() ?>