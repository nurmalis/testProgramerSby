<?= $this->extend('AdminTemplate/AdminTemplate') ?>
<?= $this->section('content') ?>

<!-- Content Row -->
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Kategori</h1>
</div>
<a class="btn btn-success btn-sm" href="<?=base_url('kategori')?>" role="button"><< KEMBALI</a>
<div class="row">
    <!-- Content Column -->
    <div class="col-lg-12 mb-4">

        <!-- Illustrations -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">FORM UBAH KATEGORI</h6>
            </div>
            <div class="card-body">
                <?php foreach($kategori as $item): ?>
                    <form method="post" action="<?= base_url('kategori/ubah') ?>">
                        <div class="form-group">
                            <label for="formGroupExampleInput">Nama Kategori </label>
                            <input type="hidden" name="id_kategori" value="<?= $item['id_kategori'] ?>">
                            <input type="text" 
                                class="form-control <?= session()->getFlashdata('errorNamaKategori')?'is-invalid':''?>" 
                                id="formGroupExampleInput" 
                                placeholder="Nama Kategori" 
                                name="nama_kategori" 
                                value="<?=$item['nama_kategori']?>">
                            <div class="invalid-feedback">
                                <?= session()->getFlashdata('errorNamaKategori')?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="UBAH" class="form-control btn btn-primary btn-sm btn-block" id="formGroupExampleInput2" placeholder="Another input">
                        </div>
                    </form>
                <?php endforeach?>
            </div>
        </div>
    </div>
</div>
   


  
<?= $this->endSection() ?>