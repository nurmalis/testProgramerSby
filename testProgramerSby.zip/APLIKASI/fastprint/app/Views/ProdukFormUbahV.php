<?= $this->extend('AdminTemplate/AdminTemplate') ?>
<?= $this->section('content') ?>

<!-- Content Row -->
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Produk</h1>
</div>
<a class="btn btn-success btn-sm" href="<?=base_url('produk')?>" role="button"><< KEMBALI</a>
<div class="row">
    <!-- Content Column -->
    <div class="col-lg-12 mb-4">

        <!-- Illustrations -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">FORM UBAH PRODUK</h6>
            </div>
            <?php if(session()->getFlashdata('errors')): ?>
    <div style="color: red;">
        <ul>
            <?php foreach(session()->getFlashdata('errors') as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div style="color: red;">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>
            <div class="card-body">
                <form action="<?= base_url('produk/ubah') ?>" method="post">
                    
                    <?= csrf_field() ?>
                    <?php foreach($produk as $itemProduk): 
                            $id_kategori    = $itemProduk['kategori_id'];
                            $id_status      = $itemProduk['status_id'];
                    ?>
                        <input type="hidden" name="id_produk" value="<?=$itemProduk['id_produk']?>">     
                        <div class="form-group">
                            <label for="formGroupExampleInput">Nama Produk</label>
                            <input  type    = "text" 
                                    class   = "form-control <?= session()->getFlashdata('errorNamaProduk')?'is-invalid':''?>" 
                                    id      = "nama_produk" 
                                    name    = "nama_produk" 
                                    value   = "<?= $itemProduk['nama_produk'] ?>" >
                            <div class="invalid-feedback">
                                <?= session()->getFlashdata('errorNamaProduk'); ?>
                            </div>
                        </div>
                            
                            <div class="form-group">
                                <label for="formGroupExampleInput">Harga</label>
                                <input  type    = "text"
                                        class   = "form-control <?=(session()->getFlashdata('errorHarga'))?'is-invalid':''?>"
                                        name    = "Harga"
                                        value   = "<?= $itemProduk['harga'] ?>">
                                <div class="invalid-feedback">
                                    <?= session()->getFlashdata('errorHarga'); ?>
                                </div>
                            </div>
                        <?php endforeach?>
                        <div class="form-group">
                            <label for="formGroupExampleInput">Kategori</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="kategori_id">
                                <?php foreach($kategori as $item): ?>
                                    <option value="<?=$item['id_kategori'] ?>" <?= ($item['id_kategori'] == $id_kategori)?'selected':''?> >
                                        <?=$item['nama_kategori']?>
                                    </option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput">Status</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="status_id">
                                <?php foreach($status as $item): ?>
                                    <option value="<?=$item['id_status'] ?>" <?= ($item['id_status'] == $id_status)?'selected':''?> >
                                        <?=$item['nama_status']?>
                                    </option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="UBAH" class="form-control btn btn-primary btn-sm btn-block" id="formGroupExampleInput2" placeholder="Another input">
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
   


  
<?= $this->endSection() ?>