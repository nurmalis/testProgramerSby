<?php

namespace App\Models;

use CodeIgniter\Model;

class StatusM extends Model
{
    protected $table            = 'status';
    protected $primaryKey       = 'id_status';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_status','nama_status'];

    protected bool $allowEmptyInserts = false;

    // // Dates
    // protected $useTimestamps = false;
    // protected $dateFormat    = 'datetime';
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // // Validation
    // protected $validationRules      = [];
    // protected $validationMessages   = [];
    // protected $skipValidation       = false;
    // protected $cleanValidationRules = true;

    // // Callbacks
    // protected $allowCallbacks = true;
    // protected $beforeInsert   = [];
    // protected $afterInsert    = [];
    // protected $beforeUpdate   = [];
    // protected $afterUpdate    = [];
    // protected $beforeFind     = [];
    // protected $afterFind      = [];
    // protected $beforeDelete   = [];
    // protected $afterDelete    = [];

    public function tampilData($katakunci = null,$start = 0,$length = 0){
        $start                  = (int) $start;
        $length                 = (int) $length;

        $db                     = \Config\Database::connect();
        $builder                = $db->table('status');
        
        if($katakunci){
            $arr                = explode(" ",$katakunci);
            for($i=0;$i<count($arr);$i++){
                $builder        = $builder->orlike('nama_status',$arr[$i]);
                $builder        = $builder->orlike('id_status',$arr[$i]);

            }
        }

        
        if($start != 0 or $length != 0){
                $builder        = $builder->limit($length,$start);
        }
       
        return $builder->orderBy('nama_status','asc')->get()->getResult();

    }
}
