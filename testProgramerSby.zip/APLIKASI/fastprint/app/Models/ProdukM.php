<?php

namespace App\Models;

use CodeIgniter\Model;

class ProdukM extends Model
{
    protected $table            = 'produk';
    protected $primaryKey       = 'id_produk';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_produk','nama_produk','harga','kategori_id','status_id'];

    protected bool $allowEmptyInserts = false;

    // // Dates
    // protected $useTimestamps = false;
    // protected $dateFormat    = 'datetime';
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // // Validation
    // protected $validationRules      = [];
    // protected $validationMessages   = [];
    // protected $skipValidation       = false;
    // protected $cleanValidationRules = true;

    // // Callbacks
    // protected $allowCallbacks = true;
    // protected $beforeInsert   = [];
    // protected $afterInsert    = [];
    // protected $beforeUpdate   = [];
    // protected $afterUpdate    = [];
    // protected $beforeFind     = [];
    // protected $afterFind      = [];
    // protected $beforeDelete   = [];
    // protected $afterDelete    = [];
    public function tampilData($katakunci = null,$start = 0,$length = 0){
        $start                  = (int) $start;
        $length                 = (int) $length;

        $db                     = \Config\Database::connect();
        $builder                = $db->table('produk');
        $builder                = $builder->select('*');
        $builder                = $builder->join('status','produk.status_id=status.id_status');
        $builder                = $builder->join('kategori','produk.kategori_id=kategori.id_kategori');
        $builder                = $builder->where('nama_status','bisa dijual');
        
        if($katakunci){
            $arr                = explode(" ",$katakunci);
            for($i=0;$i<count($arr);$i++){
                $builder        = $builder->orlike('nama_produk',$arr[$i]);
                $builder        = $builder->orlike('id_produk',$arr[$i]);
                $builder        = $builder->orlike('harga',$arr[$i]);
                $builder        = $builder->orlike('nama_kategori',$arr[$i]);
                $builder        = $builder->orlike('nama_status',$arr[$i]);

            }
        }
        
        
        if($start != 0 or $length != 0){
                $builder        = $builder->limit($length,$start);
        }
       
        
        return $builder->orderBy('nama_produk','asc')->get()->getResult();

    }
}
