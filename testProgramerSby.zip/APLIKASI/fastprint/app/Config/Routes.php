<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'ProdukC::index');

$routes->get('produk','ProdukC::index');
$routes->get('produk/formSimpan','ProdukC::formSimpan');
$routes->post('produk/simpan','ProdukC::simpan');
$routes->post('produk/dataAjax', 'ProdukC::dataAjax');
$routes->get('produk/hapus/(:segment)','ProdukC::hapus/$1');
$routes->get('produk/formUbah/(:segment)','ProdukC::formUbah/$1');
$routes->post('produk/ubah','ProdukC::ubah');

$routes->get('kategori','KategoriC::index');
$routes->get('kategori/formSimpan','KategoriC::formSimpan');
$routes->post('kategori/simpan','KategoriC::simpan');
$routes->post('kategori/dataAjax', 'KategoriC::dataAjax');
$routes->get('kategori/hapus/(:segment)','KategoriC::hapus/$1');
$routes->get('kategori/formUbah/(:segment)','KategoriC::formUbah/$1');
$routes->post('kategori/ubah','KategoriC::ubah');

$routes->get('status','StatusC::index');
$routes->get('status/formSimpan','StatusC::formSimpan');
$routes->post('status/simpan','StatusC::simpan');
$routes->post('status/dataAjax', 'StatusC::dataAjax');
$routes->get('status/hapus/(:segment)','StatusC::hapus/$1');
$routes->get('status/formUbah/(:segment)','StatusC::formUbah/$1');
$routes->post('status/ubah','StatusC::ubah');

